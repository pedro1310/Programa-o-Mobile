import React, { Component } from 'react';
import { View, Text, Button} from 'react-native';

class App extends Component{
  
  constructor(props){
    super(props);
    this.state = {
      num: 0
    };

    this.add = this.add.bind(this);
    this.exc = this.exc.bind(this);
  }
  
  add(){
    this.setState({
      num: this.state.num +1
    });
  }

  exc(){
    //Não permite que subtraia menos que 0
    if(this.state.num > 0){
      this.setState({
        num: this.state.num -1
      });
    }
      
  }

  render(){
    return(
      <View style={{ marginTop: 20, textAlign: 'center', margin: 80, textAlign: 'center'}}>

        <Text style={{fontSize: 25}}>
          Contador de Pessoas
        </Text>
        <Text style={{fontSize: 75, color: 'red', textAlign: 'center'}}>
          {this.state.num}
        </Text>
        
        <Button title="+" onPress={this.add}/>
        <Button color="#ff0000" title="-" onPress={this.exc}/>

      </View>
    )
  }
}

export default App;