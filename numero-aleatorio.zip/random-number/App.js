import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Button, Image} from 'react-native';


class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      resultado: '',
    };
    
    this.ativar = this.ativar.bind(this);
  }


  ativar(){

    this.setState({resultado: Math.floor(Math.random() * 10)});

  }

  render(){

    let img = 'https://pm1.narvii.com/6343/8d0d0b4201182c5a5fe139ed79592313d10b23e8_hq.jpg';

    return(
      <View style={styles.area}>

      <Text style={styles.titulo}>Jogo do n° aleatório</Text>

      <Image source={{ uri: img }} style={styles.img} />

      <Text style={styles.texto2}>Pense em um número de 0 a 10</Text>
      
      <Text style={styles.num}> {this.state.resultado} </Text>

      <Button style={styles.btn} title="Descobrir" color='#8D48B3' onPress={this.ativar} />

      </View>
    );
  }
}


const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  num:{
    textAlign: 'center',
    fontSize: 100,
    backgroundColor: '#8D48B3',
    borderRadius: 400/2,
    width: 150,
    height: 150,
    alignSelf: 'center',
    margin: 20,
    color: 'white'
  },
  texto2:{
    textAlign: 'center',
    fontSize: 21,
  },
  titulo:{
    fontSize: 26,
    marginTop: 20,
    alignSelf: 'center'
  },
  img:{
    width: 250, 
    height: 250,
    margin: 10,
    alignSelf: 'center',
    borderRadius: 25
  }
})


export default App;