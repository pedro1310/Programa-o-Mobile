import React, { Component } from 'react';
import { View, Text, Image } from 'react-native';

class App extends Component {
  render() {

    let nome = 'Pedro Henrique Garcia Rocha';
    let img = 'https://lh3.googleusercontent.com/WRPdHCtay62m_qIcl_37nAXckRl3EyM2j9Q8qIV-XNKOj8mAgf5HbrZKWTAz-_jFaLPzofR2dI8Wu9-mjszhYyzystczbb4AcoDzzAUYCfjXlCY6hPGUnqkAEff17OaSNwXr2phHoxx1BzYCajNfKh1qNm8PZJR1fesNMdLS_jpLKuuYKSEFL1IjLRVU-g3Qegofhs-GzWGKtZ3Dd-KPqKo0_nHFhht0v3FppWGm-AeWMOmgdC5riiUHE6IFp67We1RqtWI3Q9aO23NVOIm0rDtKAN_PDmwih9otxN0HGBeszT4ZnsP_Fg5RvZ1MgOjvYuxZhfyOCO5mYPP14XpR1iUjRd3UCzceaTbEXRoQLkuxIzYfNlu9r86pOwxhDXnG5nBmZfmXBtuYGQ9XqTglbRSdjfsq76zcZkQ4Vwm7pEj_UE49K_32rCK48FuhW_26dt_X-9Wk6FJw5-DSopolYUZ8b9x7JZwNdThFUtkQ3oNltDeGznzmBAi39ddxkhGmzTEZv-xDYThliTPn4d5FjdoVWIiz6WeHBs-zWbhnjRrT4aQu1ihVrqseNcTnQICrcKZzGa3jPoWZ66t3jy_J-8x02nWHDMLM7I_hJ154VhT0UB_IASFpOg2FUzT2eSt1zs0oM1YaB_bXRhXseib51U_nelPBEgLjVJwZgkWaP68cnXlmWWgNuRS3W_SI2vLLnnSwBJcoWOsmLLWjD4qt7f6KHQP7Ksm7eVVlqdRiUBLQg0Yq1yPUdkLXOJKP1S3QtwJtoY3vlct0-UbIfhbrxsSb9VBAryKDLThHQ0sTt6olzoa-a7MViOxhZwi-quZgfMjE3FdeMbVpJg3XDx0Fy8ESk4_HkwyXW---UfwG6W9Bd0B4410N14ok2s9hzhtSpavU4ATFb8vzfYt5patKCeh1C7U34NzN5Gh0P5tvHdgEeA=w684-h912-no?authuser=0';

    return (

      <View style={{
                justifyContent: 'center',
                alignItems: 'center',
              }}>

        <Text style={{fontSize: 25,  fontWeight: 'bold', margin: 10}}> 
         Meu perfil
        </Text>
              
        <Image source={{ uri: img }} style={{ width: 250, height: 250, margin: 5, borderRadius: 400 / 2 }} />

        <Text style={{fontSize: 25,  fontWeight: 'bold'}}> 
          Dados pessoais: 
        </Text>
        <Text style={{fontSize: 20}}> 
          Pedro Henrique Garcia Rocha 
        </Text>
        <Text style={{fontSize: 20}}> 
          19 Anos 
        </Text>

        <Text style={{fontSize: 25,  fontWeight: 'bold'}}> 
          Formação:
        </Text>
        <Text style={{fontSize: 20}}> 
          Analista e desenvolvedor de sistemas 
        </Text>

        <Text style={{fontSize: 25,  fontWeight: 'bold'}}> 
          Experiência:
        </Text>
        <Text style={{fontSize: 20}}> 
          Em busca...
        </Text>

        <Text style={{fontSize: 25,  fontWeight: 'bold'}}> 
          Projetos:
        </Text>
        <Text style={{fontSize: 20}}> 
          https://github.com/pedro1310
        </Text>

      </View>
    );
  }
}

export default App;
