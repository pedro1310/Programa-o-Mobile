import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Button, Image} from 'react-native';


class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      resultado: '',
      p: 0,
      a: 0,
    };
    
    this.calcular = this.calcular.bind(this);
  }


  calcular(){

    if ( (this.state.p === '') || (this.state.a === '') ){
      alert('É necessário digitar os valores!')
      return;
    }

    imc = this.state.p / (this.state.a * this.state.a)

    if(imc < 18.5){
      this.setState({resultado: 'Abaixo do peso'});
    }else if(imc >= 18.5 && imc < 25){
      this.setState({resultado: 'Peso normal'});
    }else if(imc >= 25 && imc < 30){
      this.setState({resultado: 'Sobrepeso'});
    }else if(imc >= 30 && imc < 35){
      this.setState({resultado: 'Obesidade grau I'});
    }else if(imc >= 35 && imc < 40){
      this.setState({resultado: 'Obesidade grau II'});
    }else if(imc >= 40){
      this.setState({resultado: 'Obesidade grau III ou Mórbida'});
    }
  }

  render(){

    let img = 'https://play-lh.googleusercontent.com/yc_iTThxehE0XKnspc_d9Hal_OgRAPY-9SeTKw_HnT1SMG_CEEkU02Xk2Y0-t-MTEQ=w240-h480-rw';

    return(
      <View style={styles.area}>

      <Text style={styles.titulo}>Cálculo do IMC</Text>

      <Image source={{ uri: img }} style={styles.img} />

      <TextInput
      style={styles.input}
      placeholder="Peso (kg)"
      onChangeText={ (valor) => this.setState({p: valor})}
      keyboardType="numeric"
      />

      <TextInput
      style={styles.input}
      placeholder="Altura (m)"
      onChangeText={ (valor) => this.setState({a: valor})}
      keyboardType="numeric"
      />

      <Button title="Calcular" color='#000000' onPress={this.calcular} />

      <Text style={styles.texto}> {this.state.resultado} </Text>

      </View>
    );
  }
}


const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  input:{
    height: 45,
    width: 250,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 20,
    padding: 10,
    alignSelf: 'center'
  },
  texto:{
    textAlign: 'center',
    fontSize: 25,
  },
  titulo:{
    fontSize: 26,
    marginTop: 20,
    alignSelf: 'center'
  },
  img:{
    width: 250, 
    height: 250,
    alignSelf: 'center'
  }
})


export default App;